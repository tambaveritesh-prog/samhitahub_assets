"""
Google Drive module (placeholder).

Will house the client and logic for reading source PDFs/files from
Google Drive (via a service account). See `README.md` in this
directory for the planned design.

No implementation yet — intentionally left empty for this stage.
"""
